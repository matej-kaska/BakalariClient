﻿using System;
using System.Windows.Forms;

namespace Bakaláři
{
    public partial class logsett : Form
    {
        int mov;
        int movX;
        int movY;
        public logsett(Form parrentForm)
        {
            InitializeComponent();
        }
        private void panelx_MouseDown(object sender, MouseEventArgs e)
        {
            mov = 1;
            movX = e.X;
            movY = e.Y;
        }
        private void panelx_MouseMove(object sender, MouseEventArgs e)
        {
            if (mov == 1)
            {
                this.SetDesktopLocation(MousePosition.X - movX, MousePosition.Y - movY);
            }
        }
        private void panelx_MouseUp(object sender, MouseEventArgs e)
        {
            mov = 0;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != Bakaláři.Properties.Settings.Default.link)
            {
                DialogResult result = MessageBox.Show("Chcete uložit změny?", "Bakaláři – Nastavení", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    if (textBox1.Text.Contains("/next"))
                    {
                        textBox1.Text = textBox1.Text.Replace("/next", "");
                    }
                    if (!textBox1.Text.EndsWith("/login.aspx"))
                    {
                        if (textBox1.Text.Contains("/login.aspx"))
                        {
                            int index = 0;
                            index = textBox1.Text.IndexOf("/login.aspx") + 11;
                            textBox1.Text = textBox1.Text.Substring(0, index);
                        }
                    }
                    Bakaláři.Properties.Settings.Default.link = textBox1.Text;
                    Bakaláři.Properties.Settings.Default.Save();
                    label5.Text = Bakaláři.Properties.Settings.Default.link;
                    this.Close();
                }
                else if (result == DialogResult.No)
                {
                    this.Close();
                }
            }
            else
            {
                this.Close();
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Contains("/next"))
            {
                textBox1.Text = textBox1.Text.Replace("/next", "");
            }
            if (!textBox1.Text.EndsWith("/login.aspx"))
            {
                if (textBox1.Text.Contains("/login.aspx"))
                {
                    int index = 0;
                    index = textBox1.Text.IndexOf("/login.aspx") + 11;
                    textBox1.Text = textBox1.Text.Substring(0, index);
                }
                else
                {
                    if (textBox1.Text.EndsWith("/"))
                    {
                        textBox1.Text = textBox1.Text.Substring(0, textBox1.Text.Length - 1);
                    }
                    textBox1.Text = textBox1.Text + "/login.aspx";
                }
            }
            Bakaláři.Properties.Settings.Default.link = textBox1.Text;
            Bakaláři.Properties.Settings.Default.Save();
            label5.Text = Bakaláři.Properties.Settings.Default.link;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "https://gymka.bakalari.cz/login.aspx";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "https://sps-kadan.bakalari.cz/login.aspx";
        }
        private void logsett_Load(object sender, EventArgs e)
        {
            label5.Text = Bakaláři.Properties.Settings.Default.link;
            textBox1.Text = Bakaláři.Properties.Settings.Default.link;
        }
        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = Bakaláři.Properties.Settings.Default.link1;
        }
        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Text = Bakaláři.Properties.Settings.Default.link2;
        }
        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text = Bakaláři.Properties.Settings.Default.link3;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form searchS = new searchSchool(this);
            try { searchS.ShowDialog(); }
            catch { }
        }
    }
}
